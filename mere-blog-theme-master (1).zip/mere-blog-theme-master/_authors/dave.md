---
title: Dave - web dev
name: Dave Mc Dave
position: Web Developer
description: Dave is a web developer
avatar: /img/dave.png
facebook: https://www.facebook.com/
twitter: https://www.twitter.com/
github: https://www.github.com/
---
Dave is a web developer. This is a page all about Dave.