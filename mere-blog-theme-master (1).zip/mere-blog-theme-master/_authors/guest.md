---
title: Guest Author - web designer
name: Guest Author
position: Web Designer
description: This is an example of a guest author
avatar: /img/guest.png
facebook: https://www.facebook.com/
twitter: https://www.twitter.com/
github: https://www.github.com/
---
This is an example page for a guest author and how the page could look. 

Add as much content about the guest author and why not link back to their blog from here by setting the `website: http://www.example.com` in the page's front matter.