---
short_name: C.S. Rhymes
title: C.S. Rhymes - web dev and author
name: C.S. Rhymes
position: Web Designer
description: C.S. Rhymes is a web developer and a part time author, specialising in Laravel, Vue.js and developing Jekyll themes.
avatar: /img/avatar.png
website: https://www.csrhymes.com
facebook: https://www.facebook.com/
twitter: https://www.twitter.com/chrisrhymes
github: https://www.github.com/chrisrhymes
gitlab: https://www.gitlab.com
instagram: https://www.instagram.com
linkedin: https://www.linkedin.com/in/chris-rhymes-a6a85971
medium: https://www.medium.com/@chrisrhymes
stack_overflow: https://stackoverflow.com/
---
C.S. Rhymes is a web developer and a part time author, specialising in Laravel, Vue.js and developing Jekyll themes.

This theme was built by C.S. Rhymes as well as the [Bulma Clean Theme](https://www.csrhymes.com/bulma-clean-theme). 